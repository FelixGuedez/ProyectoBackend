export const config = {
    db: {
        baseUrl:''
    },
    isAdmin: true
}